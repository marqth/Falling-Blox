package fr.eseo.e3.poo.projet.blox.modele;
import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;
import java.beans.PropertyChangeSupport;

public class Puits {
	public static final int LARGEUR_PAR_DEFAUT = 10;
	public static final int PROFONDEUR_PAR_DEFAUT = 20;
	public static final String MODIFICATION_PIECE_ACTUELLE = "modif piece actuelle";
	public static final String MODIFICATION_PIECE_SUIVANTE = "modif piece suivante";
	
	private int largeur;
	private int profondeur;
	private Piece pieceActuelle;
	private Piece pieceSuivante;
	private Tas tas;
	private PropertyChangeSupport pcs;
	
	public Puits(){
		this.largeur = LARGEUR_PAR_DEFAUT;
		this.profondeur = PROFONDEUR_PAR_DEFAUT;
		this.pcs = new PropertyChangeSupport(this);
		this.tas = new Tas(this);
	}
	
	public Puits(int largeur, int profondeur){		
		setLargeur(largeur);
		setProfondeur(profondeur);
		this.pcs = new PropertyChangeSupport(this);
		this.tas = new Tas(this);
	}
	
	public Puits(int largeur, int profondeur, int nbElements){		
		setLargeur(largeur);
		setProfondeur(profondeur);
		this.pcs = new PropertyChangeSupport(this);
		this.tas = new Tas(this, nbElements);
	}
	
	public Puits(int largeur, int profondeur, int nbElements, int nbLignes){		
		setLargeur(largeur);
		setProfondeur(profondeur);
		this.pcs = new PropertyChangeSupport(this);
		this.tas = new Tas(this, nbElements, nbLignes);
	}
	
	public Piece getPieceActuelle(){
		return this.pieceActuelle;
	}
	
	public Piece getPieceSuivante(){
		return this.pieceSuivante;
	}
	
	public void setPieceSuivante(Piece pieceSuivante){
		
		if (this.pieceSuivante != null) {
			getPcs().firePropertyChange(MODIFICATION_PIECE_ACTUELLE, getPieceActuelle(), getPieceSuivante());
			this.pieceActuelle = getPieceSuivante();
			this.pieceActuelle.setPosition(getLargeur()/2, -4);
			getPcs().firePropertyChange(MODIFICATION_PIECE_SUIVANTE, getPieceSuivante(), pieceSuivante);
			this.pieceSuivante = pieceSuivante;
			this.pieceSuivante.setPuits(this);
		}else{
			getPcs().firePropertyChange(MODIFICATION_PIECE_SUIVANTE, getPieceSuivante(), pieceSuivante);
			this.pieceSuivante = pieceSuivante;
			this.pieceSuivante.setPuits(this);
		}
	}

	public int getLargeur() {
		return largeur;
	}

	public void setLargeur(int largeur){
		if(largeur < 5 || largeur > 15){
			throw new IllegalArgumentException("Erreur, la largeur n'est pas entre 5 ou 15");
		}else{
			this.largeur = largeur;
		}
	}

	public int getProfondeur() {
		return profondeur;
	}

	public void setProfondeur(int profondeur) {
		if(profondeur < 15 || profondeur > 25) {
			throw new IllegalArgumentException("Erreur, la profondeur n'est pas entre 15 ou 25");
		}else{
			this.profondeur = profondeur;
		}
	}
	
	public Tas getTas() {
		return this.tas;
	}
	
	public void setTas(Tas tas) {
		this.tas = tas;
	}
	
	public PropertyChangeSupport getPcs() {
		return this.pcs;
	}
	
	@Override	
	public String toString(){
		String chain = getClass().getSimpleName() + " : Dimension " + getLargeur() + " x " + getProfondeur() + "\n" + "Piece Actuelle : ";
		if(getPieceActuelle() == null) {
			chain += "<aucune>" + "\n" + "Piece Suivante : ";
		}else {
			chain += getPieceActuelle().toString() + "Piece Suivante : ";
		}
		
		if(getPieceSuivante() == null) {
			chain += "<aucune>" + "\n";
		}else {
			chain += getPieceSuivante().toString();
		}
		return chain;
	}
	
	public void addPropertyChangeListener(java.beans.PropertyChangeListener listener) {
		getPcs().addPropertyChangeListener(listener);
	}
	
	public void removePropertyChangeListener(java.beans.PropertyChangeListener listener) {
		getPcs().removePropertyChangeListener(listener);
		
	}
	
	private void gererCollision() throws BloxException {
		this.tas.ajouterElements(getPieceActuelle());		
		UsineDePiece.setMode(3);
		this.setPieceSuivante(UsineDePiece.genererPiece());	
	}
	
	public void gravite() throws BloxException {
		try {
			this.getPieceActuelle().deplacerDe(0,1);
		} catch (BloxException exception) {
			if(exception.getType() == 1) {
				this.gererCollision();
			}
		}
	}
	
	public void echangerPieces() {
		Piece pieceActuelleClone = getPieceActuelle().clone();
		this.setPieceSuivante(pieceActuelleClone);
	}
}
