package fr.eseo.e3.poo.projet.blox.vue;

import fr.eseo.e3.poo.projet.blox.modele.Tas;

public class VueTas {
	public static final double MULTIPLIER_NUANCE = 0.4;
	
	private final VuePuits vuePuits;
	private final Tas tas;
	
	public VueTas(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
		this.tas = vuePuits.getPuits().getTas();
	}

	public VuePuits getVuePuits() {
		return vuePuits;
	}

	public Tas getTas() {
		return tas;
	}
	
	public java.awt.Color nuance(java.awt.Color couleur){
		double r = couleur.getRed();
		double g = couleur.getGreen();
		double b = couleur.getBlue();
		
		r = r * (1 - MULTIPLIER_NUANCE);
		g = g * (1 - MULTIPLIER_NUANCE);
		b = b * (1 - MULTIPLIER_NUANCE);
		
		int red   = (int)r;
		int green = (int)g;
		int blue  = (int)b;
		
		return new java.awt.Color(red, green, blue);
	}
	
	public void afficher(java.awt.Graphics2D g2D) {
		for (int i = 0; i < getTas().getElements().length; i++) {
			for(int j = 0; j < getTas().getElements()[0].length; j++) {
				if(getTas().getElements()[i][j] != null) {
					g2D.setColor(nuance(getTas().getElements()[i][j].getCouleur().getCouleurPourAffichage()));
					g2D.fill3DRect(getTas().getElements()[i][j].getCoordonnees().getAbscisse()*getVuePuits().getTaille(),
						getTas().getElements()[i][j].getCoordonnees().getOrdonnee()*getVuePuits().getTaille(),
						getVuePuits().getTaille(), getVuePuits().getTaille(), true);
				}
			}
		}
	}
}
