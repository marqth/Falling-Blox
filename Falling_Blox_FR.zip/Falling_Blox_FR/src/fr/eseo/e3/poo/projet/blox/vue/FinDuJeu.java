package fr.eseo.e3.poo.projet.blox.vue;

import java.awt.Graphics;

public class FinDuJeu extends javax.swing.JPanel {
	
	public FinDuJeu() {
		
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		char[] perdu = { 'V', 'o', 'u', 's', ' ', 'a', 'v', 'e', 'z', ' ', 'p', 'e', 'r', 'd', 'u', ' ', '!'};
		char[] partieTerminee = { 'L', 'a', ' ', 'p', 'a', 'r', 't', 'i', 'e', ' ', 'e', 's', 't',
				' ', 't', 'e', 'r', 'm', 'i', 'n', 'é', 'e'};
		char[] quitter1 = { 'C', 'l', 'i', 'q', 'u', 'e', 'z', ' ', 's', 'u', 'r', ' ', 'l', 'a', ' ', 'c', 'r', 
				 'o', 'i', 'x', ' ', 'p', 'o', 'u', 'r'};
		char[] quitter2 = {'a', 'r', 'r', 'ê', 't', 'e', 'r', ' ', 'l', 'e', ' ', 'p', 'r', 'o', 'g', 'r', 'a', 'm', 'm', 'e'};

		g.drawChars(perdu, 0, perdu.length, 7, 20);
		g.drawChars(partieTerminee, 0, partieTerminee.length, 7, 40);
		g.drawChars(quitter1, 0, quitter1.length, 7, 60);
		g.drawChars(quitter2, 0, quitter2.length, 7, 80);
	}
}
