package fr.eseo.e3.poo.projet.blox.modele;

import java.util.Random;

import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;

public class Tas {
	
	private Puits puits;
	private Element[][] elements;
	private int score = 0;
	private int totalLignesCompletees = 0;
	private boolean ligneComplete;
	
	public Tas(Puits puits) {
		this.puits = puits;
		this.elements = new Element[puits.getProfondeur()][puits.getLargeur()];
	}
	
	public Tas(Puits puits, int nbElements) {
		this(puits, nbElements, nbElements/puits.getLargeur() + 1);
	}
	
	public Tas(Puits puits, int nbElements, int nbLignes) {
		this.puits = puits;
		this.elements = new Element[puits.getProfondeur()][puits.getLargeur()];
		this.construireTas(nbElements, nbLignes, new Random());
	}
	
	public Puits getPuits() {
		return puits;
	}
	public void setPuits(Puits puits) {
		this.puits = puits;
	}
	public Element[][] getElements() {
		return elements;
	}
	public void setElements(Element[][] elements) {
		this.elements = elements;
	}
	
	public int getScore() {
		return this.score;
	}
	
	public int getTotalLignesCompletees() {
		return this.totalLignesCompletees;
	}
	
	public boolean getLigneComplete() {
		return this.ligneComplete;
	}
	
	public void setLigneComplete(boolean ligneComplete) {
		this.ligneComplete = ligneComplete;
	}
	
	public void ajouterScore(int lignes) {
		if(lignes == 1){
			this.score+= 10;
		}else if(lignes == 2) {
			this.score+= 25;
		}else if(lignes == 3) {
			this.score+= 50;
		}else if(lignes == 4) {
			this.score+= 100;
		}else {
			
		}
	}
	
	private void construireTas(int nbElements, int nbLignes, java.util.Random rand) {
		if(nbElements != 0 && nbElements >= nbLignes * getPuits().getLargeur()) {
			throw new IllegalArgumentException("Il ne peut y avoir un nombre d'elements supérieur à la capacité du tas");
		}else {
			int nbElementsPlaces = 0;
			int ord;
			int abs;
			Couleur indiceCouleur = null;
			while (nbElementsPlaces != nbElements){
				ord = getPuits().getProfondeur() - (rand.nextInt(nbLignes) + 1);
				abs = rand.nextInt(getPuits().getLargeur());
				if(this.elements[ord][abs] == null) {
					indiceCouleur = Couleur.getRandomCouleur(rand);
					this.elements[ord][abs] = new Element(abs, ord, indiceCouleur);
					nbElementsPlaces++;
				}
			}	
		}
	}
	
	public void ajouterElements(Piece piece) throws BloxException {
		for(int i = 0; i < piece.getElements().size(); i++) {
			int abs = piece.getElements().get(i).getCoordonnees().getAbscisse();
			int ord = piece.getElements().get(i).getCoordonnees().getOrdonnee();
			if(ord >= 0 && ord < this.elements.length) {
				this.elements[ord][abs] = piece.getElements().get(i);
			}else {
				throw new BloxException("La pièce est toujours hors du puits", 3);
			}
		}		
		verifLigneComplete();		
	}
	
	private void verifLigneComplete() {
		int nbElementsLigne;
		int nbLignesEnUneFois = 0;
		for(int i = 0; i < this.elements.length; i++) {
			nbElementsLigne = 0;
			for(int j = 0; j< this.elements[0].length; j++) {
				if(this.elements[i][j] != null) {
					nbElementsLigne++;
				}
			}
			
			if(nbElementsLigne == this.elements[0].length){
				descendreLigne(i);
				nbLignesEnUneFois++;
				this.totalLignesCompletees++;
			}
		}
		this.ajouterScore(nbLignesEnUneFois);
		if(nbLignesEnUneFois > 0) {
			this.ligneComplete = true;
		}else {
			this.ligneComplete = false;
		}
	}
	
	private void descendreLigne(int i) {
		for(int j = 0; j < this.elements[0].length; j++) {
			this.elements[i][j] = null;
		}
		for(int k = i-1; k >= 0; k--) {
			for(int l = 0; l < this.elements[0].length; l++){
				if(this.elements[k][l] != null) {
					Element element = this.elements[k][l];
					element.getCoordonnees().setOrdonnee(this.elements[k][l].getCoordonnees().getOrdonnee()+1);
					this.elements[k][l] = null;
					this.elements[element.getCoordonnees().getOrdonnee()][element.getCoordonnees().getAbscisse()] = element;
				}
			}
		}
	}
}
