package fr.eseo.e3.poo.projet.blox.vue;

import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;

public class VuePiece {
	public static final double MULTIPLIER_TEINTE = 0.3;
	public static final double MULTIPLIER_TRANSPARENCE = 0.1;
	private final Piece piece;
	private final int taille;
	
	public VuePiece(Piece piece, int taille) {
		this.piece = piece;
		this.taille = taille;
	}
	
	public Piece getPiece() {
		return this.piece;
	}
	
	public int getTaille() {
		return this.taille;
	}
	
	public java.awt.Color teinte(java.awt.Color couleur){
		double r = couleur.getRed();
		double g = couleur.getGreen();
		double b = couleur.getBlue();
		
		r = r+(255-r)*MULTIPLIER_TEINTE;
		g = g+(255-g)*MULTIPLIER_TEINTE;
		b = b+(255-b)*MULTIPLIER_TEINTE;
		
		int red = (int)r;
		int green = (int)g;
		int blue = (int)b;
		
		return new java.awt.Color(red, green, blue);
	}
	
	public java.awt.Color transparence(java.awt.Color couleur){
		double r = couleur.getRed();
		double g = couleur.getGreen();
		double b = couleur.getBlue();
		
		r = r+(255-r)*MULTIPLIER_TRANSPARENCE;
		g = g+(255-g)*MULTIPLIER_TRANSPARENCE;
		b = b+(255-b)*MULTIPLIER_TRANSPARENCE;
		
		int red = (int)r;
		int green = (int)g;
		int blue = (int)b;
		
		return new java.awt.Color(red, green, blue);
	}
	
	public void afficherPiece(java.awt.Graphics2D g2D) {
		g2D.setColor(teinte(getPiece().getElements().get(0).getCouleur().getCouleurPourAffichage()));
		g2D.fill3DRect(getPiece().getElements().get(0).getCoordonnees().getAbscisse()*getTaille(),
		getPiece().getElements().get(0).getCoordonnees().getOrdonnee()*getTaille(),getTaille(), getTaille(), true);
		g2D.setColor(getPiece().getElements().get(2).getCouleur().getCouleurPourAffichage());
		for (int i = 1; i < 4; i++) {
			g2D.fill3DRect(getPiece().getElements().get(i).getCoordonnees().getAbscisse()*getTaille(),
			getPiece().getElements().get(i).getCoordonnees().getOrdonnee()*getTaille(),getTaille(), getTaille(), true);
		}
		/*Piece pieceFantome = getPiece().clone();
		pieceFantome.placerAuFond();
		g2D.setColor(transparence(getPiece().getElements().get(0).getCouleur().getCouleurPourAffichage()));
		for (int i = 0; i < 4; i++) {
			g2D.fill3DRect(pieceFantome.getElements().get(i).getCoordonnees().getAbscisse()*getTaille(),
			pieceFantome.getElements().get(i).getCoordonnees().getOrdonnee()*getTaille(),getTaille(), getTaille(), true);
		}*/
	}
	
	public void afficherPiecePanneau(java.awt.Graphics2D g2D) {
		g2D.setColor(teinte(getPiece().getElements().get(0).getCouleur().getCouleurPourAffichage()));
		g2D.fill3DRect(getPiece().getElements().get(0).getCoordonnees().getAbscisse()*getTaille()+20,
		(getPiece().getElements().get(0).getCoordonnees().getOrdonnee())*getTaille()+15, getTaille(), getTaille(), true);
		g2D.setColor(getPiece().getElements().get(2).getCouleur().getCouleurPourAffichage());
		for (int i = 1; i < 4; i++) {
			g2D.fill3DRect(getPiece().getElements().get(i).getCoordonnees().getAbscisse()*getTaille()+20,
			(getPiece().getElements().get(i).getCoordonnees().getOrdonnee())*getTaille()+15, getTaille(), getTaille(), true);
		}
	}
}
