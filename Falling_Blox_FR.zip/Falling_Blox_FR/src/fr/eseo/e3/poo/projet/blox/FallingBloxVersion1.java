package fr.eseo.e3.poo.projet.blox;

import java.awt.BorderLayout;
import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.JFrame;
import fr.eseo.e3.poo.projet.blox.controleur.ControleClavier;
import fr.eseo.e3.poo.projet.blox.controleur.Gravite;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.UsineDePiece;
import fr.eseo.e3.poo.projet.blox.vue.PanneauInformation;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;

public class FallingBloxVersion1 {
	
	private FallingBloxVersion1(String [] args) {
		if(args.length == 0){
			constructionJeu0();
		}else if(args.length == 1) {
			constructionJeu1(Integer.parseInt(args[0]));
		}else if(args.length == 2) {
			constructionJeu2(Integer.parseInt(args[0]), Integer.parseInt(args[1]));
		}else {
			String [] args2 = new String[2];
			args2[0] = args[0];
			args2[1] = args[1];
			new FallingBloxVersion1(args2);
			//throw new IllegalArgumentException("Le main ne peut prendre plus de 2 arguments");
		}
	}
	
	private static void ajoutMusique(String path) { //Réalisé avec l'aide de Julien Racki
        try {
        	AudioInputStream musique = AudioSystem.getAudioInputStream(new File(path));
        	Clip clip = AudioSystem.getClip();
        	clip.open(musique);
        	clip.loop(Clip.LOOP_CONTINUOUSLY);
        }
        	catch(Exception e) {
        }
    }
	
	private static void constructionJeu0() {
		Puits puits = new Puits();
		VuePuits vuePuits = new VuePuits(puits, 25);
		JFrame cadre = new JFrame("Falling Blox");
		ControleClavier k = new ControleClavier(vuePuits);
		new Gravite(vuePuits);
		vuePuits.getPuits().addPropertyChangeListener(vuePuits);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		cadre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cadre.add(vuePuits);
		cadre.addKeyListener(k);
		cadre.add(new PanneauInformation(puits), BorderLayout.EAST);
		cadre.setSize(1000, 1000);
		cadre.setResizable(false);
		cadre.setVisible(true);
		cadre.pack();
		cadre.setLocationRelativeTo(null);
		ajoutMusique("FallingBlox.wav");
	}
	
	private static void constructionJeu1(int nbElements) {
		Puits puits = new Puits(Puits.LARGEUR_PAR_DEFAUT, Puits.PROFONDEUR_PAR_DEFAUT, nbElements);
		VuePuits vuePuits = new VuePuits(puits, 25);
		JFrame cadre = new JFrame("Falling Blox");
		ControleClavier k = new ControleClavier(vuePuits);
		new Gravite(vuePuits);
		vuePuits.getPuits().addPropertyChangeListener(vuePuits);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		cadre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cadre.add(vuePuits);
		cadre.addKeyListener(k);
		cadre.add(new PanneauInformation(puits), BorderLayout.EAST);
		cadre.setSize(1000, 1000);	
		cadre.setResizable(false);
		cadre.setVisible(true);
		cadre.pack();
		cadre.setLocationRelativeTo(null);
		ajoutMusique("FallingBlox.wav");
	}
	
	private static void constructionJeu2(int nbElements, int nbLignes) {
		Puits puits = new Puits(Puits.LARGEUR_PAR_DEFAUT, Puits.PROFONDEUR_PAR_DEFAUT, nbElements, nbLignes);
		VuePuits vuePuits = new VuePuits(puits, 25);
		JFrame cadre = new JFrame("Falling Blox");
		ControleClavier k = new ControleClavier(vuePuits);
		new Gravite(vuePuits);
		vuePuits.getPuits().addPropertyChangeListener(vuePuits);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		cadre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cadre.add(vuePuits);
		cadre.addKeyListener(k);
		cadre.add(new PanneauInformation(puits), BorderLayout.EAST);
		cadre.setSize(1000, 1000);
		cadre.setResizable(false);
		cadre.setVisible(true);
		cadre.pack();
		cadre.setLocationRelativeTo(null);
		ajoutMusique("FallingBlox.wav");
	}
	
	public static void main (String [] args) {		
		new FallingBloxVersion1(args);
	}
}