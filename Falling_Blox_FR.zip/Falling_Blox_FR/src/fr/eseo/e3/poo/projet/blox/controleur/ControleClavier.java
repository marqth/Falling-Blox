package fr.eseo.e3.poo.projet.blox.controleur;

import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;
import java.awt.event.KeyEvent;

public class ControleClavier extends java.awt.event.KeyAdapter {
	private Puits puits;
	private VuePuits vuePuits;
	
	public ControleClavier(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
		this.puits = this.vuePuits.getPuits();
	}
	
	public Puits getPuits() {
		return puits;
	}

	public void setPuits(Puits puits) {
		this.puits = puits;
	}

	public VuePuits getVuePuits() {
		return vuePuits;
	}

	public void setVuePuits(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
	}
	
	private void keyDeplacementPiece(KeyEvent event) {
		
		if(event.getKeyCode() == KeyEvent.VK_LEFT) {
			try {
				getVuePuits().getVuePiece().getPiece().deplacerDe(-1, 0);
			} catch (BloxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(event.getKeyCode() == KeyEvent.VK_RIGHT) {
			try {
				getVuePuits().getVuePiece().getPiece().deplacerDe(1, 0);
			} catch (BloxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(event.getKeyCode() == KeyEvent.VK_DOWN) {
			try {
				getVuePuits().getVuePiece().getPiece().deplacerDe(0, 1);
			} catch (BloxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	private void keyRotationPiece(KeyEvent event) {
		if(event.getKeyCode() == KeyEvent.VK_CONTROL) {
			try {
				getVuePuits().getVuePiece().getPiece().tourner(false);
			} catch (BloxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if(event.getKeyCode() == KeyEvent.VK_SHIFT) {
			try {
				getVuePuits().getVuePiece().getPiece().tourner(true);
			} catch (BloxException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	@Override
	public void keyPressed(KeyEvent event) {
		keyDeplacementPiece(event);
		keyRotationPiece(event);
		
		if(event.getKeyCode() == KeyEvent.VK_UP) {
			getPuits().echangerPieces();
		}else if(event.getKeyCode() == KeyEvent.VK_SPACE) {
			getVuePuits().getVuePiece().getPiece().placerAuFond();
		}
		
		this.vuePuits.repaint();
		
	}

}
