package fr.eseo.e3.poo.projet.blox.controleur;

import java.awt.event.ActionEvent;
import javax.swing.JFrame;
import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.vue.FinDuJeu;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;

public class Gravite implements java.awt.event.ActionListener {

	private javax.swing.Timer timer;
	private final Puits puits;
	private final VuePuits vuePuits;
	
	public Gravite(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
		this.puits = vuePuits.getPuits();
		this.timer = new javax.swing.Timer(2000, this);
		this.timer.start();
	}
	
	public int getPeriodicite() {
		return this.timer.getDelay();
	}
	
	public void setPeriodicite(int periodicite) {
		this.timer.setDelay(periodicite);
	}
	
	public javax.swing.Timer getTimer() {
		return timer;
	}

	public void setTimer(javax.swing.Timer timer) {
		this.timer = timer;
	}

	public Puits getPuits() {
		return puits;
	}

	public VuePuits getVuePuits() {
		return vuePuits;
	}
	
	private void augmentationGravite(int totalLignesCompletees) {
		if(totalLignesCompletees > 10) {
			this.setPeriodicite(1500);
		}else if(totalLignesCompletees > 25) {
			this.setPeriodicite(1000);
		}else if(totalLignesCompletees > 50) {
			this.setPeriodicite(750);
		}else if(totalLignesCompletees > 75) {
			this.setPeriodicite(500);
		}else if(totalLignesCompletees > 100) {
			this.setPeriodicite(250);
		}else if(totalLignesCompletees > 200) {
			this.setPeriodicite(100);
		}/*else if(totalLignesCompletees > 500) {
			this.setPeriodicite(50);
		}*/
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if(getPuits().getTas().getLigneComplete()) {
			int totalLignesCompletees = this.getPuits().getTas().getTotalLignesCompletees();
			this.augmentationGravite(totalLignesCompletees);
			this.getPuits().getTas().setLigneComplete(false);
		}
		try {
			this.puits.gravite();
			this.vuePuits.repaint();
		}catch(BloxException blox) {
			if(blox.getType() == 3) {
				this.timer.stop();
				JFrame fenetre = new JFrame("Fin du jeu");
				FinDuJeu fin = new FinDuJeu();
				fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				fenetre.add(fin);
				fenetre.setSize(150, 150);
				fenetre.setResizable(true);
				fenetre.setVisible(true);
				fenetre.setLocationRelativeTo(null);
				fin.paintComponent(fenetre.getGraphics());	
			}	
		}
	}
}
