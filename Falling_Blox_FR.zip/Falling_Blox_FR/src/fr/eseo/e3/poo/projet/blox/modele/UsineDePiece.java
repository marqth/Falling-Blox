//Réalisé en collaboration avec Antoine Morin

package fr.eseo.e3.poo.projet.blox.modele;

import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.SPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.TPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.ZPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.OPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.IPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.JPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.LPiece;

import java.util.Random;

public class UsineDePiece {
	public static final int CYCLIC = 1;
	public static final int ALEATOIRE_COMPLET = 2;
	public static final int ALEATOIRE_PIECE = 3;
	
	private static int mode = ALEATOIRE_PIECE;
	private static int cycle = 0;
	
	private UsineDePiece() {
		
	}
	
	static int getMode() {
		return mode;
	}
	
	static int getCycle() {
		return cycle;
	}
	
	public static void setMode(int i) {
		if(i == 1) {
			mode = CYCLIC;
		}else if(i == 2) {
			mode = ALEATOIRE_COMPLET;
		}else {
			mode = ALEATOIRE_PIECE;
		}
	}
	
	public static Piece genererPiece() {
		Piece piece = null;
		if(mode == CYCLIC) {
			piece = genererPieceCyclique();
		}else if(mode == ALEATOIRE_COMPLET){
			piece = genererPieceAleatoireComplet();
		}else if(mode == ALEATOIRE_PIECE){
			piece = genererPieceAleatoirePiece();
		}
		return piece;
	}
	
	private static  Piece genererPieceCyclique() {
		Piece piece = null;
		if(cycle == 0) {
			piece = new OPiece(new Coordonnees(2,3), Couleur.ROUGE);
			cycle++;
		}else if(cycle == 1) {
			piece = new IPiece(new Coordonnees(2,3), Couleur.ORANGE);
			cycle++;
		}else if(cycle == 2) {
			piece = new TPiece(new Coordonnees(2,3), Couleur.BLEU);
			cycle++;
		}else if(cycle == 3) {
			piece = new LPiece(new Coordonnees(2,3), Couleur.VERT);
			cycle++;
		}else if(cycle == 4) {
			piece = new JPiece(new Coordonnees(2,3), Couleur.JAUNE);
			cycle++;
		}else if(cycle == 5) {
			piece = new ZPiece(new Coordonnees(2,3), Couleur.CYAN);
			cycle++;
		}else {//if(cycle == 6) {
			piece = new SPiece(new Coordonnees(2,3), Couleur.VIOLET);
			cycle = 0;
		}
		return piece;
	}
	
	private static Piece genererPieceAleatoirePiece() {
		Piece piece = null;
		Random r = new Random();
		Couleur couleur = Couleur.values()[r.nextInt(7)];
		if(couleur == Couleur.ROUGE) {
			piece = new OPiece(new Coordonnees(2,3), Couleur.ROUGE);
		}else if(couleur == Couleur.ORANGE) {
			piece = new IPiece(new Coordonnees(2,3), Couleur.ORANGE);
		}else if(couleur == Couleur.BLEU) {
			piece = new TPiece(new Coordonnees(2,3), Couleur.BLEU);
		}else if(couleur == Couleur.VERT) {
			piece = new LPiece(new Coordonnees(2,3), Couleur.VERT);
		}else if(couleur == Couleur.JAUNE) {
			piece = new JPiece(new Coordonnees(2,3), Couleur.JAUNE);
		}else if(couleur == Couleur.CYAN) {
			piece = new ZPiece(new Coordonnees(2,3), Couleur.CYAN);
		}else {//if(couleur == Couleur.VIOLET) {
			piece = new SPiece(new Coordonnees(2,3), Couleur.VIOLET);
		}
		return piece;
	}
	
	private static Piece genererPieceAleatoireComplet() {
		Piece piece = null;
		Random r = new Random();
		int numero = r.nextInt(7);
		Couleur couleur = Couleur.values()[r.nextInt(7)];
		if(numero == 0) {
			piece = new OPiece(new Coordonnees(2,3), couleur);
		}else if(numero == 1) {
			piece = new IPiece(new Coordonnees(2,3), couleur);
		}else if(numero == 2) {
			piece = new TPiece(new Coordonnees(2,3), couleur);
		}else if(numero == 3) {
			piece = new LPiece(new Coordonnees(2,3), couleur);
		}else if(numero == 4) {
			piece = new JPiece(new Coordonnees(2,3), couleur);
		}else if(numero == 5) {
			piece = new ZPiece(new Coordonnees(2,3), couleur);
		}else {//if(numero == 6) {
			piece = new SPiece(new Coordonnees(2,3), couleur);
		}
		return piece;
	}
}
