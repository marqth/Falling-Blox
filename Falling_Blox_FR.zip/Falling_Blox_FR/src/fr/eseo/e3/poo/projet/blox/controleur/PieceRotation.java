package fr.eseo.e3.poo.projet.blox.controleur;

import java.awt.event.MouseEvent;
import javax.swing.SwingUtilities;
import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;

public class PieceRotation extends java.awt.event.MouseAdapter {
	
	private Puits puits;
	private VuePuits vuePuits;
	
	public PieceRotation(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
		this.puits = this.vuePuits.getPuits();
	}
	
	public Puits getPuits() {
		return puits;
	}

	public void setPuits(Puits puits) {
		this.puits = puits;
	}

	public VuePuits getVuePuits() {
		return vuePuits;
	}

	public void setVuePuits(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
	}
	
	@Override
	public void mouseClicked(MouseEvent event) {
		if(SwingUtilities.isLeftMouseButton(event)){
				try {
					getVuePuits().getVuePiece().getPiece().tourner(false);
				} catch (BloxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}else if(SwingUtilities.isRightMouseButton(event)) {
				try {
					getVuePuits().getVuePiece().getPiece().tourner(true);
				} catch (BloxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		this.vuePuits.repaint();
	}	
}
