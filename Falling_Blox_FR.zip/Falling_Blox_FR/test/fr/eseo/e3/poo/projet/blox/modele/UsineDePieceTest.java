package fr.eseo.e3.poo.projet.blox.modele;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;

public class UsineDePieceTest {

	@Test
	void testUsineDePiece() {
		Puits puits = new Puits();
		assertEquals(UsineDePiece.getMode(),3,"Le mode n'est pas à 3 par défaut");
		assertEquals(UsineDePiece.getCycle(),0,"Le mode n'est pas à 0 par défaut");
		puits.setPieceSuivante(UsineDePiece.genererPiece());
		assertNotNull(puits.getPieceSuivante(), "La piece n'a pas été générée");
		UsineDePiece.setMode(2);
		assertEquals(UsineDePiece.getMode(),2,"Le mode n'a pas été changé");
		puits.setPieceSuivante(UsineDePiece.genererPiece());
		assertNotNull(puits.getPieceSuivante(), "La piece n'a pas été générée");
		UsineDePiece.setMode(1);
		assertEquals(UsineDePiece.getMode(),1,"Le mode n'a pas été changé");
		puits.setPieceSuivante(UsineDePiece.genererPiece());
		assertNotNull(puits.getPieceSuivante(), "La piece n'a pas été générée");
		UsineDePiece.setMode(3);
		assertEquals(UsineDePiece.getMode(),3,"Le mode n'a pas été changé");
	}

}
