package fr.eseo.e3.poo.projet.blox.vue;

import static org.junit.jupiter.api.Assertions.assertEquals;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.UsineDePiece;

import org.junit.jupiter.api.Test;

public class VuePuitsTest {

	@Test
	public void testVuePuits() {
		Puits puits = new Puits();
		Puits puits1 = new Puits(5,15);
		VuePuits vuePuits1 = new VuePuits(puits);
		VuePuits vuePuits2 = new VuePuits(puits, 20);
		VuePiece vuePiece1 = new VuePiece(UsineDePiece.genererPiece(), 20);
		assertEquals(vuePuits1.getPuits(), puits, "Le puits du 1er constructeur n'a pas été correctement initialisé");
		assertEquals(vuePuits1.getTaille(), 15, "La taille du 1er constructeur n'a pas été correctement initialisé");
		assertEquals(vuePuits2.getPuits(), puits, "Le puits du 2ème constructeur n'a pas été correctement initialisé");
		assertEquals(vuePuits2.getTaille(), 20, "La taille du 2ème constructeur n'a pas été correctement initialisé");
		vuePuits1.setPuits(puits1);
		vuePuits1.setTaille(20);
		assertEquals(vuePuits1.getPuits(), puits1, "Le puits n'a pas correctement été modifié");
		assertEquals(vuePuits1.getTaille(), 20, "La taille n'a pas été correctement modifiée");
	}

}
