package fr.eseo.e3.poo.projet.blox.controleur;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.UsineDePiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;

public class PieceDeplacementTest {

	public PieceDeplacementTest() {
		testDeplacementPiece();
	}
	
	private void testDeplacementPiece() {
		Puits puits = new Puits();
		VuePuits vuePuits = new VuePuits(puits);
		UsineDePiece.setMode(1);
		Piece piece = UsineDePiece.genererPiece();
		JFrame cadre = new JFrame("Puits");
		vuePuits.getPuits().addPropertyChangeListener(vuePuits);
		vuePuits.getPuits().setPieceSuivante(piece);
		vuePuits.getPuits().setPieceSuivante(piece);
		vuePuits.getPuits().getPieceActuelle().setPosition(2, 4);
		cadre.add(vuePuits);
		cadre.setSize(1000, 1000);		
		cadre.setVisible(true);
		cadre.pack();
		cadre.setLocationRelativeTo(null);
	}
	
	public static void main (String [] args) {
		SwingUtilities.invokeLater(new Runnable () {
		@Override
			public void run() {
				new PieceDeplacementTest();
			}
		});
	}

}
