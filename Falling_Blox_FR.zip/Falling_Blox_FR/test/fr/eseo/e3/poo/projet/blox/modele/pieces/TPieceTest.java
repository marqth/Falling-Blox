package fr.eseo.e3.poo.projet.blox.modele.pieces;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Coordonnees;
import fr.eseo.e3.poo.projet.blox.modele.Couleur;
import fr.eseo.e3.poo.projet.blox.modele.Element;

class TPieceTest {

	@Test
	void test() throws BloxException {
		Coordonnees coordonnees = new Coordonnees(0,0);
		Couleur couleur = Couleur.CYAN;
		TPiece tpiece = new TPiece(coordonnees, couleur);
		assertEquals(tpiece.getElements().get(0), new Element(new Coordonnees(0,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(tpiece.getElements().get(1), new Element(new Coordonnees(-1,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(tpiece.getElements().get(2), new Element(new Coordonnees(1,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(tpiece.getElements().get(3), new Element(new Coordonnees(0,1), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(tpiece.toString(), "TPiece :" + "\n" + "	(0, 0) - CYAN" + "\n" + "	(-1, 0) - CYAN" + "\n"
		+ "	(1, 0) - CYAN"+ "\n" + "	(0, 1) - CYAN" +"\n", "Le toString() ne fonctionne pas");
		tpiece.deplacerDe(1,1);
		assertEquals(tpiece.getElements().get(0).getCoordonnees(), new Coordonnees(1,1), "Le deplacement n'a pas été fait");
		tpiece.tourner(false);
		tpiece.tourner(true);
	}

}
