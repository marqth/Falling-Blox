package fr.eseo.e3.poo.projet.blox.modele.pieces;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Coordonnees;
import fr.eseo.e3.poo.projet.blox.modele.Couleur;
import fr.eseo.e3.poo.projet.blox.modele.Element;

class LPieceTest {

	@Test
	void testLPiece() throws BloxException {
		Coordonnees coordonnees = new Coordonnees(0,0);
		Couleur couleur = Couleur.CYAN;
		LPiece lpiece = new LPiece(coordonnees, couleur);
		assertEquals(lpiece.getElements().get(0), new Element(new Coordonnees(0,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(lpiece.getElements().get(1), new Element(new Coordonnees(1,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(lpiece.getElements().get(2), new Element(new Coordonnees(0,-1), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(lpiece.getElements().get(3), new Element(new Coordonnees(0,-2), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(lpiece.toString(), "LPiece :" + "\n" + "	(0, 0) - CYAN" + "\n" + "	(1, 0) - CYAN" + "\n"
		+ "	(0, -1) - CYAN"+ "\n" + "	(0, -2) - CYAN" +"\n", "Le toString() ne fonctionne pas");
		lpiece.deplacerDe(1,1);
		assertEquals(lpiece.getElements().get(0).getCoordonnees(), new Coordonnees(1,1), "Le deplacement n'a pas été fait");
		lpiece.tourner(false);
		lpiece.tourner(true);
	}

}
