package fr.eseo.e3.poo.projet.blox.controleur;

//import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class GraviteTest {

	@Test
	void test() {
		
	}

}
