package fr.eseo.e3.poo.projet.blox.modele;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.jupiter.api.Test;

public class CoordonneesTest {

	@Test
	void testCoordonnees() {
		Coordonnees coordonnee1 = new Coordonnees(0,0);
		Coordonnees coordonnee2 = new Coordonnees(1,-2);

		assertEquals(coordonnee1.getAbscisse(), 0, "L'abscisse n'a pas été correctement implémentée");
		assertEquals(coordonnee1.getOrdonnee(), 0, "L'ordonnée n'a pas été correctement implémentée");
		assertFalse(coordonnee1.equals(coordonnee2), "Les deux coordonnees sont égales");
		assertFalse(coordonnee1.equals(null), "Les deux coordonnees sont égales");
		assertFalse(coordonnee1.equals(new Puits()), "Les deux coordonnees sont égales");
		coordonnee1.setAbscisse(1);
		assertFalse(coordonnee1.equals(coordonnee2), "Les deux coordonnees sont égales");
		coordonnee1.setOrdonnee(-2);
		assertEquals(coordonnee1.getAbscisse(), 1, "L'abscisse n'a pas été correctement modifiée");
		assertEquals(coordonnee1.getOrdonnee(), -2, "L'ordonnée n'a pas été correctement modifiée");
		assertTrue(coordonnee1.equals(coordonnee1), "Les deux coordonnees ne sont pas égales");
		assertTrue(coordonnee1.equals(coordonnee2), "Les deux coordonnees ne sont pas égales");
		assertEquals(coordonnee1.toString(), "(1, -2)", "Le toString() n'est pas bon");
		int hash = coordonnee1.hashCode();
		assertEquals(hash, new Coordonnees(1,-2).hashCode(), "Le hashcode n'est pas le bon");
		}
}
