package fr.eseo.e3.poo.projet.blox.modele;

//import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class TasTest {

	@Test
	void testTas() {
		
	}

}
