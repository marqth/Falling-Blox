package fr.eseo.e3.poo.projet.blox.modele;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import org.junit.jupiter.api.Test;

public class ElementTest {

	@Test
	void testElement() {
		Coordonnees coordonnees1 = new Coordonnees(0,0);
		Couleur couleur = Couleur.CYAN;
		Element element1 = new Element(coordonnees1, couleur);
		Element element2 = new Element(1, 1);
		Element element3 = new Element(coordonnees1);
		Element element4 = new Element(1, -2, couleur);
		assertEquals(element1.getCoordonnees(), new Coordonnees(0,0), "Les coordonnees n'ont pas été correctement implémentées");
		assertEquals(element2.getCoordonnees(), new Coordonnees(1,1), "Les coordonnees n'ont pas été correctement implémentées");
		assertEquals(element3.getCoordonnees(), new Coordonnees(0,0), "Les coordonnees n'ont pas été correctement implémentées");
		assertEquals(element4.getCoordonnees(), new Coordonnees(1,-2), "Les coordonnees n'ont pas été correctement implémentées");
		assertEquals(element1.getCouleur(), Couleur.CYAN, "La couleur n'a pas été correctement implémentée");
		assertEquals(element2.getCouleur(), Couleur.ROUGE, "La couleur n'a pas été correctement implémentée");
		assertEquals(element3.getCouleur(), Couleur.ROUGE, "La couleur n'a pas été correctement implémentée");
		assertEquals(element4.getCouleur(), Couleur.CYAN, "La couleur n'a pas été correctement implémentée");
		Coordonnees coordonnees2 = new Coordonnees(1,-2);
		assertFalse(element2.equals(element4), "Les deux éléments ne sont pas égaux");
		element2.setCoordonnees(coordonnees2);
		assertFalse(element2.equals(element4), "Les deux éléments ne sont pas égaux");
		element2.setCouleur(Couleur.CYAN);
		assertEquals(element2.getCoordonnees(), new Coordonnees(1,-2), "Les coordonnees n'ont pas été correctement modifiées");
		assertEquals(element2.getCouleur(), Couleur.CYAN, "La couleur n'a pas été correctement modifiée");
		assertEquals(element2.toString(), "(1, -2) - CYAN", "Le toString() ne fonctionne pas correctement");
		assertTrue(element2.equals(element4), "Les deux éléments ne sont pas égaux");
		assertTrue(element2.equals(element2), "Les deux éléments ne sont pas égaux");
		assertFalse(element2.equals(null), "Les deux éléments sont égaux");
		assertFalse(element2.equals(coordonnees1), "Les deux éléments sont égaux");
		int hash = element1.hashCode();
		assertEquals(hash, new Element(coordonnees1, couleur).hashCode(), "Le hashcode n'est pas le bon");
		element1.deplacerDe(1, 1);
		assertEquals(element1, new Element(new Coordonnees(1,1), couleur), "Les deux éléments ne sont pas égaux");
	}
}
