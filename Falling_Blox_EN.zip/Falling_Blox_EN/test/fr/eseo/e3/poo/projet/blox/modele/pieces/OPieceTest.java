package fr.eseo.e3.poo.projet.blox.modele.pieces;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;
import fr.eseo.e3.poo.projet.blox.modele.Coordonnees;
import fr.eseo.e3.poo.projet.blox.modele.Couleur;
import fr.eseo.e3.poo.projet.blox.modele.Element;


public class OPieceTest {

	@Test
	void testOPiece() {
		Coordonnees coordonnees = new Coordonnees(0,0);
		Couleur couleur = Couleur.CYAN;
		OPiece opiece = new OPiece(coordonnees, couleur);
		assertEquals(opiece.getElements().get(0), new Element(new Coordonnees(0,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(opiece.getElements().get(1), new Element(new Coordonnees(1,0), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(opiece.getElements().get(2), new Element(new Coordonnees(0,-1), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(opiece.getElements().get(3), new Element(new Coordonnees(1,-1), Couleur.CYAN), "Le constructeur est mal fait");
		assertEquals(opiece.toString(), "OPiece :" + "\n" + "	(0, 0) - CYAN" + "\n" + "	(1, 0) - CYAN" + "\n" 
		+ "	(0, -1) - CYAN"+ "\n" + "	(1, -1) - CYAN" +"\n", "Le toString() ne fonctionne pas");
		assertThrows(IllegalArgumentException.class, () -> opiece.tourner(true));
		assertThrows(IllegalArgumentException.class, () -> opiece.tourner(false));
		assertThrows(IllegalArgumentException.class, () -> opiece.deplacerDe(0, 1));
	}
}
