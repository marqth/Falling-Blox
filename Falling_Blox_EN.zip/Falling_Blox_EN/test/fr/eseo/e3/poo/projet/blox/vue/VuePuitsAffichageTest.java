package fr.eseo.e3.poo.projet.blox.vue;

//import static org.junit.jupiter.api.Assertions.*;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;
import org.junit.jupiter.api.Test;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.UsineDePiece;

public class VuePuitsAffichageTest {

	@Test
	public void testVuePuitsAffichage() {
		
	}
	
	public VuePuitsAffichageTest() {
		testConstructeurPuits();
		testConstructeurPuitsTaille();
	}
	
	private void testConstructeurPuits() {
		Puits puits = new Puits();
		VuePuits vuePuits = new VuePuits(puits);
		UsineDePiece.setMode(1);
		JFrame cadre = new JFrame("Puits");
		vuePuits.getPuits().addPropertyChangeListener(vuePuits);
		UsineDePiece.setMode(1);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		UsineDePiece.setMode(2);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		UsineDePiece.setMode(3);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().getPieceActuelle().setPosition(2, 4);
		cadre.add(vuePuits);
		cadre.setSize(1000, 1000);		
		cadre.setVisible(true);
		cadre.pack();
		cadre.setLocationRelativeTo(null);
	}
	
	private void testConstructeurPuitsTaille() {
		Puits puits = new Puits();
		VuePuits vuePuits = new VuePuits(puits, 25);
		UsineDePiece.setMode(0);
		JFrame cadre = new JFrame("Puits et taille");
		vuePuits.getPuits().addPropertyChangeListener(vuePuits);
		UsineDePiece.setMode(2);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		UsineDePiece.setMode(3);
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().setPieceSuivante(UsineDePiece.genererPiece());
		vuePuits.getPuits().getPieceActuelle().setPosition(2, 4);
		cadre.add(vuePuits);
		cadre.setSize(1000, 1000);
		cadre.setVisible(true);
		cadre.pack();
		cadre.setLocationRelativeTo(null);
	}
	
	
	public static void main (String [] args) {
		SwingUtilities.invokeLater(new Runnable () {
		@Override
			public void run() {
				new VuePuitsAffichageTest();
			}
		});
	}
}
