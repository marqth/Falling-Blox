package fr.eseo.e3.poo.projet.blox.modele;

import static org.junit.jupiter.api.Assertions.assertEquals;
import java.util.Random;
import org.junit.jupiter.api.Test;
import fr.eseo.e3.poo.projet.blox.modele.pieces.OPiece;


public class CouleurTest {

	@Test
	void testCouleur() {
		//Couleur couleur = new Couleur(java.awt.Color.RED);
		OPiece opiece1 = new OPiece(new Coordonnees(0,0), Couleur.ROUGE);
		assertEquals(opiece1.getElements().get(0).getCouleur().getCouleurPourAffichage(),
				java.awt.Color.RED, "La couleur n'est pas la bonne");
		Random r = new Random();
		OPiece opiece2 = new OPiece(new Coordonnees(0,0), Couleur.getRandomCouleur(r));
	}
}
