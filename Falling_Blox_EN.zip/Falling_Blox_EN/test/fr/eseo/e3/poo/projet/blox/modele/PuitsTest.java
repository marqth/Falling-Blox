package fr.eseo.e3.poo.projet.blox.modele;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import org.junit.jupiter.api.Test;
import fr.eseo.e3.poo.projet.blox.modele.pieces.IPiece;
import fr.eseo.e3.poo.projet.blox.modele.pieces.OPiece;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;

public class PuitsTest {

	@Test//(expected = IllegalArgumentException.class)
	void testPuits() throws IllegalArgumentException, BloxException {
		Puits puits1 = new Puits();
		Puits puits2 = new Puits(15,25);
		Puits puits3 = new Puits(15,25,5);
		Puits puits4 = new Puits(15,25,5,5);
		puits1.setTas(puits4.getTas());
		assertEquals(puits1.getLargeur(), 10, "La largeur n'a pas correctement été initialisée");
		assertEquals(puits1.getProfondeur(), 20, "La profondeur n'a pas correctement été initialisée");
		assertThrows(IllegalArgumentException.class, () -> puits1.setLargeur(20));
		assertThrows(IllegalArgumentException.class, () -> puits1.setLargeur(1));
		assertThrows(IllegalArgumentException.class, () -> puits1.setProfondeur(30));
		assertThrows(IllegalArgumentException.class, () -> puits1.setProfondeur(10));
		assertEquals(puits2.getLargeur(), 15, "La largeur n'a pas correctement été initialisée");
		assertEquals(puits2.getProfondeur(), 25, "La profondeur n'a pas correctement été initialisée");
		assertEquals(puits2.toString(),"Puits : Dimension 15 x 25" + "\n" + "Piece Actuelle : <aucune>" + "\n"
		+ "Piece Suivante : <aucune>" + "\n","Le toString() ne fonctionne pas correctement");		
		puits2.setLargeur(5);
		puits2.setProfondeur(15);
		assertEquals(puits2.getLargeur(), 5, "La largeur n'a pas correctement été changée");
		assertEquals(puits2.getProfondeur(), 15, "La profondeur n'a pas correctement été changée");
		assertEquals(puits2.toString(),"Puits : Dimension 5 x 15" + "\n" + "Piece Actuelle : <aucune>" + "\n"
		+ "Piece Suivante : <aucune>" + "\n","Le toString() ne fonctionne pas correctement");
		IPiece ipiece = new IPiece(new Coordonnees(0,0), Couleur.CYAN);
		OPiece opiece = new OPiece(new Coordonnees(0,0), Couleur.ROUGE);
		puits2.setPieceSuivante(opiece);
		assertEquals(puits2.toString(),"Puits : Dimension 5 x 15" + "\n" + "Piece Actuelle : <aucune>" + "\n" +
		"Piece Suivante : OPiece :" + "\n" + "	(0, 0) - ROUGE" + "\n" + "	(1, 0) - ROUGE" + "\n" + "	(0, -1) - ROUGE"
		+ "\n" + "	(1, -1) - ROUGE" +"\n","Le toString() ne fonctionne pas correctement");
		puits2.setPieceSuivante(ipiece);
		assertEquals(puits2.toString(),"Puits : Dimension 5 x 15" + "\n" + "Piece Actuelle : OPiece :" + "\n"
		+ "	(2, -4) - ROUGE"+ "\n" + "	(3, -4) - ROUGE" + "\n" + "	(2, -5) - ROUGE" + "\n" + "	(3, -5) - ROUGE" +"\n"
		+ "Piece Suivante : IPiece :" + "\n" + "	(0, 0) - CYAN" + "\n" + "	(0, 1) - CYAN" + "\n" + "	(0, -1) - CYAN"
		+ "\n" + "	(0, -2) - CYAN" +"\n","Le toString() ne fonctionne pas correctement");
		VuePuits vuePuits = new VuePuits(puits1);
		puits1.addPropertyChangeListener(vuePuits);
		puits1.removePropertyChangeListener(vuePuits);
		opiece.setPosition(0, puits2.getProfondeur());
		puits2.gravite();
		puits2.gravite();
		puits2.getPieceActuelle().tourner(false);
		puits2.getPieceActuelle().tourner(true);
		assertThrows(IllegalArgumentException.class, () -> puits2.getPieceActuelle().deplacerDe(0, -2));
		assertThrows(IllegalArgumentException.class, () -> puits2.getPieceActuelle().deplacerDe(2, 0));
		assertThrows(IllegalArgumentException.class, () -> puits2.getPieceActuelle().deplacerDe(-2, 0));
		assertThrows(IllegalArgumentException.class, () -> puits2.getPieceActuelle().deplacerDe(0, 2));
		opiece.setPosition(0, puits2.getProfondeur()-1);
/*		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().tourner(true));
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().tourner(false));
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().deplacerDe(-1, 0));
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().deplacerDe(0, 1));
		opiece.setPosition(puits2.getLargeur(), puits2.getProfondeur()-1);
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().tourner(true));
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().tourner(false));
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().deplacerDe(1, 0));
		assertThrows(BloxException.class, () -> puits2.getPieceActuelle().deplacerDe(0, 1));
*/	}
}
