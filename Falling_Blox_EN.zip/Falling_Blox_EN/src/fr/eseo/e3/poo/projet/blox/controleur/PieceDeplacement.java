package fr.eseo.e3.poo.projet.blox.controleur;

import java.awt.event.MouseEvent;
import java.awt.event.MouseWheelEvent;
import javax.swing.SwingUtilities;
import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.vue.VuePuits;

public class PieceDeplacement extends java.awt.event.MouseAdapter {
	
	private Puits puits;
	private VuePuits vuePuits;
	private int colonne;
	private int nbEvents = 0;
	
	public PieceDeplacement(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
		this.puits = vuePuits.getPuits();
	}
	
	public Puits getPuits() {
		return puits;
	}

	public void setPuits(Puits puits) {
		this.puits = puits;
	}

	public VuePuits getVuePuits() {
		return vuePuits;
	}

	public void setVuePuits(VuePuits vuePuits) {
		this.vuePuits = vuePuits;
	}
	
	public int getColonne() {
		return colonne;
	}

	public void setColonne(int colonne) {
		this.colonne = colonne;
	}

	public int getNbEvents() {
		return nbEvents;
	}

	public void setNbEvents(int nbEvents) {
		this.nbEvents = nbEvents;
	}
		
	@Override
	public void mouseMoved(MouseEvent event) {
		int colonneActuelle = event.getX()/getVuePuits().getTaille();
		if(getPuits().getPieceActuelle() != null) {
			if(nbEvents == 0) {
				this.nbEvents ++;
				this.colonne = colonneActuelle;
			}else {
				if(colonneActuelle != getColonne()) {
					int dx = colonneActuelle - getColonne();
					try {
						getVuePuits().getVuePiece().getPiece().deplacerDe(dx, 0);
					} catch (BloxException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					this.colonne = colonneActuelle;
				}
			}
			this.vuePuits.repaint();
		}
	}

	@Override
	public void mouseEntered(MouseEvent event) {
		this.colonne = event.getX()/getVuePuits().getTaille();
	}


	@Override
	public void mouseWheelMoved(MouseWheelEvent event) {
		if(getPuits().getPieceActuelle() != null) {
			if(event.getWheelRotation() > 0) {
				try {
					getVuePuits().getVuePiece().getPiece().deplacerDe(0, 1);
				} catch (BloxException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}else if(event.getWheelRotation() < 0) {
				getPuits().echangerPieces();
			}
			this.vuePuits.repaint();
		}
	}	
	
	@Override
	public void mouseClicked(MouseEvent event) {
		if(SwingUtilities.isMiddleMouseButton(event)) {
			getVuePuits().getVuePiece().getPiece().placerAuFond();
		}
		this.vuePuits.repaint();
	}
}
