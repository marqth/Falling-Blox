package fr.eseo.e3.poo.projet.blox.vue;

import fr.eseo.e3.poo.projet.blox.controleur.PieceDeplacement;
import fr.eseo.e3.poo.projet.blox.controleur.PieceRotation;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Dimension;
import java.beans.PropertyChangeListener;

public class VuePuits extends javax.swing.JPanel implements PropertyChangeListener {
	public static final int TAILLE_PAR_DEFAUT = 15;
	private final VueTas vueTas;
	
	private Puits puits;
	private int taille;
	private VuePiece vuePiece;
	private PanneauInformation panneauInformation;
	
	public VuePuits(Puits puits) {
		this.setPuits(puits);
		this.taille = TAILLE_PAR_DEFAUT;
		this.vueTas = new VueTas(this);
		this.setPreferredSize(new Dimension(puits.getLargeur()*getTaille(),puits.getProfondeur()*getTaille()));
		getPuits().addPropertyChangeListener(this);
		this.addMouseMotionListener(new PieceDeplacement(this));
		this.addMouseWheelListener(new PieceDeplacement(this));
		this.addMouseListener(new PieceDeplacement(this));
		this.addMouseListener(new PieceRotation(this));
	}
	
	public VuePuits(Puits puits, int taille) {
		this.setPuits(puits);
		this.taille = taille;
		this.vueTas = new VueTas(this);
		this.setPreferredSize(new Dimension(puits.getLargeur()*getTaille(),puits.getProfondeur()*getTaille()));
		getPuits().addPropertyChangeListener(this);
		this.addMouseMotionListener(new PieceDeplacement(this));
		this.addMouseWheelListener(new PieceDeplacement(this));
		this.addMouseListener(new PieceDeplacement(this));
		this.addMouseListener(new PieceRotation(this));
	}

	public Puits getPuits() {
		return this.puits;
	}

	public void setPuits(Puits puits) {
		this.puits = puits;
		this.puits.addPropertyChangeListener(this);
		this.setPreferredSize(new Dimension(puits.getLargeur()*getTaille(),puits.getProfondeur()*getTaille()));
	}

	public int getTaille() {
		return this.taille;
	}

	public void setTaille(int taille) {
		this.taille = taille;
		this.setPreferredSize(new Dimension(this.puits.getLargeur()*taille,this.puits.getProfondeur()*taille));
	}
	
	public VuePiece getVuePiece() {
		return this.vuePiece;
	}
	
	private void setVuePiece(VuePiece vuePiece) {
		this.vuePiece = vuePiece;
	}
	
	public VueTas getVueTas() {
		return this.vueTas;
	}
	
	public PanneauInformation getPanneauInformation() {
		return panneauInformation;
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		/* appel vers super pour remplir le fond du JPanel */
		/*Le paramètre g est copie en utilisant la méthode copie()
		* puis converti en instance de Graphics2D grâce à
		* un transtypage (cast) explicite.
		*/
		Graphics2D g2D = (Graphics2D)g.create();
		/* Nous utiliserons l'instance de Graphics2D*/
		/*Puis nous liberons la memoire*/
		g2D.setPaint(java.awt.Color.WHITE);
		g2D.fillRect(0,  0,  getPuits().getLargeur()*this.getTaille(), getPuits().getProfondeur()*this.getTaille());
		g2D.setPaint(java.awt.Color.LIGHT_GRAY);
		//int hauteur = g2D.getFontMetrics().getHeight();
		//int largeur = g2D.getFontMetrics().getWidths()[0];
		for (int i = 0; i < getPuits().getLargeur()+1; i++) {
			g2D.drawLine(i*getTaille(), 0, i*getTaille() ,getPuits().getProfondeur()*getTaille());
		}
		for (int j = 0; j < getPuits().getProfondeur()+1; j++) {
			g2D.drawLine(0, j*getTaille(), getPuits().getLargeur()*getTaille(), j*getTaille());
		}
		/*for (int i = 0; i < getPuits().getLargeur()+1; i++) {
			g2D.drawLine(i*getTaille(), (hauteur - getPuits().getProfondeur()*getTaille())/2,
			i*getTaille() ,(hauteur + getPuits().getProfondeur()*getTaille())/2);
		}*/
		/*for (int j = 0; j < getPuits().getProfondeur()+1; j++) {
			g2D.drawLine(largeur/2 - getPuits().getLargeur()*getTaille()/2, j*getTaille(),
			largeur/2 + getPuits().getLargeur()*getTaille()/2, j*getTaille());
		}*/
		
		if(getVueTas() != null) {
			getVueTas().afficher(g2D);
		}
		
		if(getVuePiece() != null) {
			getVuePiece().afficherPiece(g2D);
		}
		
		g2D.dispose();		
	}
	
	public void propertyChange(java.beans.PropertyChangeEvent event) {
		if(event.getPropertyName().equals("modif piece actuelle")) {
			Piece piece = (Piece) event.getNewValue();
			this.setVuePiece(new VuePiece(piece, this.getTaille()));
		}
		this.repaint();	
	}
}
