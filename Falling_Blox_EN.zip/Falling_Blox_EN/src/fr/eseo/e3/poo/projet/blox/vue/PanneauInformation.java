	package fr.eseo.e3.poo.projet.blox.vue;

import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.beans.PropertyChangeEvent;

import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.pieces.Piece;

public class PanneauInformation extends javax.swing.JPanel implements java.beans.PropertyChangeListener {
	
	private Puits puits;
	private VuePiece vuePiece;
	
	public PanneauInformation(Puits puits) {
		this.puits = puits;
		this.vuePiece = new VuePiece(puits.getPieceSuivante(), 10);
		puits.addPropertyChangeListener(this);
		this.setPreferredSize(new Dimension(100, 70)); //Mettre le 1er à 100
	}
	
	public Puits getPuits() {
		return this.puits;
	}
	
	public VuePiece getVuePiece() {
		return vuePiece;
	}

	public void setVuePiece(VuePiece vuePiece) {
		this.vuePiece = vuePiece;
	}
	
	@Override
	public void propertyChange(PropertyChangeEvent event) {
		if(event.getPropertyName().equals(Puits.MODIFICATION_PIECE_SUIVANTE)) {
			this.setVuePiece(new VuePiece((Piece) event.getNewValue(), 10));
			repaint();
		}	
	}
	
	protected void paintComponent(Graphics g) {
		super.paintComponent(g);
		int pointsInt = getPuits().getTas().getScore();
		String pointsString = Integer.toString(pointsInt);
		char[] pieceSuivante = { 'N', 'e', 'x', 't', ' ', 'P', 'i', 'e', 'c', 'e', ' ', ':' };
		char[] score = {'S', 'c', 'o', 'r', 'e', ' ', ':' };
		char[] points = new char[pointsString.length()];
		for(int i=0; i<pointsString.length();i++){
			points[i] = pointsString.charAt(i);
		}
		g.drawChars(pieceSuivante, 0, pieceSuivante.length, 7, 20);
		g.drawChars(score, 0, score.length, 7, 100);
		g.drawChars(points, 0, points.length, 50, 100);
		/* appel vers super pour remplir le fond du JPanel */
		/*Le paramètre g est copie en utilisant la méthode copie()
		* puis converti en instance de Graphics2D grâce à
		* un transtypage (cast) explicite.
		*/
		Graphics2D g2D = (Graphics2D)g.create();
		if(getVuePiece() != null) {
			g2D.setPaint(getVuePiece().getPiece().getElements().get(0).getCouleur().getCouleurPourAffichage());
			getVuePiece().afficherPiecePanneau(g2D);
		}
	}
}
