//Réalisé en collaboration avec Robin Nouteau
package fr.eseo.e3.poo.projet.blox.modele.pieces;

import java.util.ArrayList;
import java.util.List;

import fr.eseo.e3.poo.projet.blox.modele.BloxException;
import fr.eseo.e3.poo.projet.blox.modele.Coordonnees;
import fr.eseo.e3.poo.projet.blox.modele.Couleur;
import fr.eseo.e3.poo.projet.blox.modele.Element;
import fr.eseo.e3.poo.projet.blox.modele.Puits;
import fr.eseo.e3.poo.projet.blox.modele.UsineDePiece;

public abstract class Piece {
	
	private List<Element> elements; 
	private Puits puits;
	
	public Piece(Coordonnees coordonnees, Couleur couleur) {
		this.elements = new ArrayList<Element>();
		this.elements.add(new Element(coordonnees, couleur));
		this.elements.add(new Element(coordonnees, couleur));
		this.elements.add(new Element(coordonnees, couleur));
		this.elements.add(new Element(coordonnees, couleur));
	}
	
	public List<Element> getElements() {
		return elements;
	}
	
	protected abstract void setElements(Coordonnees coordonnees, Couleur couleur);
	
	public void setPosition(int abscisse, int ordonnee) {
		this.setElements(new Coordonnees(abscisse, ordonnee), getElements().get(0).getCouleur());
	}
	
	@Override
	public String toString() {
		String chain = getClass().getSimpleName() + " :";
		for(int i = 0; i<this.getElements().size(); i++){
			chain += "\n" + "	(" + this.getElements().get(i).getCoordonnees().getAbscisse()
					+ ", " + this.getElements().get(i).getCoordonnees().getOrdonnee() + ") - "
					+ this.getElements().get(i).getCouleur();
		}
		chain += "\n";
		return chain;
	}

	public Puits getPuits() {
		return puits;
	}

	public void setPuits(Puits puits) {
		this.puits = puits;
	}	
	
	public Piece clone() {
		Couleur couleur = this.getElements().get(1).getCouleur();
		UsineDePiece.setMode(1);
		Piece pieceClone = UsineDePiece.genererPiece();
		while(pieceClone.getClass() != this.getClass() && pieceClone.getElements().get(1).getCouleur() != couleur) {
			pieceClone = UsineDePiece.genererPiece();
		}
		return pieceClone;
	}
	
	public void deplacerDe(int dX, int dY) throws BloxException {
		if(dX > 1 || dX < -1 || dY > 1 || dY < 0) {
			throw new IllegalArgumentException("La piece ne peut pas se deplacer de plus d'un bloc à la fois ou vers le haut");
		}else {
			if(this.getPuits() != null) {
				verificationEligibiliteDeplacement(dX, dY);
			}
		}
		for(int i = 0; i < getElements().size(); i++) {
			this.elements.get(i).deplacerDe(dX, dY);
		}	
	}
	
	public void tourner(boolean sensHoraire) throws BloxException {
		int abs = this.getElements().get(0).getCoordonnees().getAbscisse();
		int ord = this.getElements().get(0).getCoordonnees().getOrdonnee();
		
		if(this.getPuits() != null) {
			for(int i = 1; i < this.elements.size(); i++) {	
				if(sensHoraire) {
					verificationEligibiliteRotationSensHoraire(i, abs, ord);
				}else {
					verificationEligibiliteRotationSensAntiHoraire(i, abs, ord);
				}
			}
		}
		for(int i = 1; i < this.elements.size(); i++) {
			int dx = this.elements.get(i).getCoordonnees().getAbscisse() - this.elements.get(0).getCoordonnees().getAbscisse();
			int dy = this.elements.get(i).getCoordonnees().getOrdonnee() - this.elements.get(0).getCoordonnees().getOrdonnee();
			if(sensHoraire) {
				this.elements.get(i).setCoordonnees(new Coordonnees(this.elements.get(0).getCoordonnees().getAbscisse() - dy,
						this.elements.get(0).getCoordonnees().getOrdonnee() + dx));
			}else {
				this.elements.get(i).setCoordonnees(new Coordonnees(this.elements.get(0).getCoordonnees().getAbscisse() + dy,
						this.elements.get(0).getCoordonnees().getOrdonnee() - dx));
			}	
		}
	}
	
	public void placerAuFond() {
		boolean deplacementValide = true;
		while(deplacementValide) {
			try {
				this.deplacerDe(0, 1);
			} catch (BloxException e) {
				deplacementValide = false;
			}
		}
	}
	
	private void verificationEligibiliteDeplacement(int dX, int dY) throws BloxException {
		for(int i = 0; i < getElements().size(); i++) {
			if(this.elements.get(i).getCoordonnees().getAbscisse() + dX < 0) {
				throw new BloxException("La piece ne peut pas sortir du puits", 2);
			}else if(this.elements.get(i).getCoordonnees().getAbscisse() + dX  >= getPuits().getLargeur()) {
				throw new BloxException("La piece ne peut pas sortir du puits", 2);
			}else if(this.elements.get(i).getCoordonnees().getOrdonnee() + dY >= getPuits().getProfondeur()){
				throw new BloxException("La piece a touché le fond", 1);
			}
			else if(this.elements.get(i).getCoordonnees().getOrdonnee() + dY >=0) {
				if(this.getPuits().getTas().getElements()[this.elements.get(i).getCoordonnees().getOrdonnee() + dY]
						[this.elements.get(i).getCoordonnees().getAbscisse() + dX] != null) {
					throw new BloxException("Il y a déjà un élément à cette position", 1);
				}
			}
		}
	}
	
	private void verificationEligibiliteRotationSensHoraire(int i, int abs, int ord) throws BloxException {
		int dx=this.elements.get(i).getCoordonnees().getAbscisse()-this.elements.get(0).getCoordonnees().getAbscisse();
		int dy=this.elements.get(i).getCoordonnees().getOrdonnee()-this.elements.get(0).getCoordonnees().getOrdonnee();
		if(abs - dy < 0 || abs - dy >= getPuits().getLargeur()) {
			throw new BloxException("La piece ne peut pas sortir du puits", 2);
		}else if(ord + dx > getPuits().getProfondeur()-1) {
			throw new BloxException("La piece a touché le fond", 1);
		}else if(ord + dx >=0) {
			if(this.getPuits().getTas().getElements()[ord + dx][abs - dy] != null) {
				throw new BloxException("Il y a déjà un élément à cette position", 1);
			}
		}
	}
	
	private void verificationEligibiliteRotationSensAntiHoraire(int i, int abs, int ord) throws BloxException {
		int dx=this.elements.get(i).getCoordonnees().getAbscisse()-this.elements.get(0).getCoordonnees().getAbscisse();
		int dy=this.elements.get(i).getCoordonnees().getOrdonnee()-this.elements.get(0).getCoordonnees().getOrdonnee();
		if(abs + dy < 0 || abs + dy >= getPuits().getLargeur()) {
			throw new BloxException("La piece ne peut pas sortir du puits", 2);
		}else if(ord - dx > getPuits().getProfondeur()-1) {
			throw new BloxException("La piece a touché le fond", 1);
		}else if(ord - dx >=0) {
			if(this.getPuits().getTas().getElements()[ord - dx][abs + dy] != null) {
				throw new BloxException("Il y a déjà un élément à cette position", 1);
			}
		}
	}
	
	
}
