package fr.eseo.e3.poo.projet.blox.vue;

import java.awt.Graphics;

public class FinDuJeu extends javax.swing.JPanel {
	
	public FinDuJeu() {
		
	}
	
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		char[] perdu = { 'G', 'a', 'm', 'e', ' ', 'O', 'v', 'e', 'r', ' ', '!'};
		char[] partieTerminee = { 'Y', 'o', 'u', ' ', 'L', 'o', 's', 't'};
		char[] quitter1 = { 'C', 'l', 'i', 'c', 'k', ' ', 'o', 'n', ' ', 't', 'h', 'e', ' ', 'c', 'r', 'o', 's', 
				 's', ' ', 't', 'o'};
		char[] quitter2 = {'q', 'u', 'i', 't', ' ', 't', 'h', 'e', ' ', 'g', 'a', 'm', 'e'};

		g.drawChars(perdu, 0, perdu.length, 7, 20);
		g.drawChars(partieTerminee, 0, partieTerminee.length, 7, 40);
		g.drawChars(quitter1, 0, quitter1.length, 7, 60);
		g.drawChars(quitter2, 0, quitter2.length, 7, 80);
	}
}
